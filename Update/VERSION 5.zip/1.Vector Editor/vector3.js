
// TEXT PANEL CONTROL ......................................................

// ----------------------
// TEXT PANEL CONTROLS
// ----------------------
const fontFamilySelect = document.getElementById('fontFamily');
const fontSizeInput = document.getElementById('fontSize');
const boldBtn = document.getElementById('boldBtn');
const italicBtn = document.getElementById('italicBtn');
const underlineBtn = document.getElementById('underlineBtn');
const strikeBtn = document.getElementById('strikeBtn');

const alignLeftBtn = document.getElementById('alignLeft');
const alignCenterBtn = document.getElementById('alignCenter');
const alignRightBtn = document.getElementById('alignRight');

// Helper to update selected text object
function updateTextProperty(property, value) {
  const obj = canvas.getActiveObject();
  if (obj && obj.type === 'i-text') {
    obj.set(property, value);
    canvas.renderAll();
  }
}

// Font family change
fontFamilySelect.addEventListener('change', () => {
  updateTextProperty('fontFamily', fontFamilySelect.value);
});

// Font size change
fontSizeInput.addEventListener('input', () => {
  updateTextProperty('fontSize', parseInt(fontSizeInput.value));
});

// Bold toggle
boldBtn.addEventListener('click', () => {
  const obj = canvas.getActiveObject();
  if (obj && obj.type === 'i-text') {
    obj.set('fontWeight', obj.fontWeight === 'bold' ? 'normal' : 'bold');
    canvas.renderAll();
  }
});

// Italic toggle
italicBtn.addEventListener('click', () => {
  const obj = canvas.getActiveObject();
  if (obj && obj.type === 'i-text') {
    obj.set('fontStyle', obj.fontStyle === 'italic' ? 'normal' : 'italic');
    canvas.renderAll();
  }
});

// Underline toggle
underlineBtn.addEventListener('click', () => {
  const obj = canvas.getActiveObject();
  if (obj && obj.type === 'i-text') {
    obj.set('underline', !obj.underline);
    canvas.renderAll();
  }
});

// Strikethrough toggle
strikeBtn.addEventListener('click', () => {
  const obj = canvas.getActiveObject();
  if (obj && obj.type === 'i-text') {
    obj.set('linethrough', !obj.linethrough);
    canvas.renderAll();
  }
});

// Alignment
alignLeftBtn.addEventListener('click', () => {
  updateTextProperty('textAlign', 'left');
});
alignCenterBtn.addEventListener('click', () => {
  updateTextProperty('textAlign', 'center');
});
alignRightBtn.addEventListener('click', () => {
  updateTextProperty('textAlign', 'right');
});

// ----------------------
// OPTIONAL: Auto-update panel when selecting text
// ----------------------
canvas.on('selection:created', syncTextPanel);
canvas.on('selection:updated', syncTextPanel);



function syncTextPanel(obj) {
  if (obj && obj.type === 'i-text') {
    fontFamilySelect.value = obj.fontFamily || 'Arial';
    fontSizeInput.value = obj.fontSize || 32;
    boldBtn.classList.toggle('active', obj.fontWeight === 'bold');
    italicBtn.classList.toggle('active', obj.fontStyle === 'italic');
    underlineBtn.classList.toggle('active', !!obj.underline);
    strikeBtn.classList.toggle('active', !!obj.linethrough);

    alignLeftBtn.classList.toggle('active', obj.textAlign === 'left');
    alignCenterBtn.classList.toggle('active', obj.textAlign === 'center');
    alignRightBtn.classList.toggle('active', obj.textAlign === 'right');
  }
}

// Update when selecting
canvas.on('selection:created', (e) => {
  const obj = e.selected[0];
  syncTextPanel(obj);
});
canvas.on('selection:updated', (e) => {
  const obj = e.selected[0];
  syncTextPanel(obj);
});

// Update live while typing
canvas.on('text:changed', (e) => {
  syncTextPanel(e.target);
});



