function openEditor(page) {
  window.open(page, "_blank");
}
