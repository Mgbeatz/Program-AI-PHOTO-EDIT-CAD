// Export as SVG
document.getElementById('export-svg').addEventListener('click', () => {
  const svgData = canvas.toSVG();
  const blob = new Blob([svgData], { type: 'image/svg+xml' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = 'vector_drawing.svg';
  link.click();
});

// Export as PNG
document.getElementById('export-png').addEventListener('click', () => {
  const dataURL = canvas.toDataURL({ format: 'png' });
  const link = document.createElement('a');
  link.href = dataURL;
  link.download = 'vector_drawing.png';
  link.click();
});

// Export as JPEG
document.getElementById('export-jpeg').addEventListener('click', () => {
  const dataURL = canvas.toDataURL({ format: 'jpeg', quality: 0.9 });
  const link = document.createElement('a');
  link.href = dataURL;
  link.download = 'vector_drawing.jpg';
  link.click();
});

// Import SVG
document.getElementById('import-svg').addEventListener('change', function (e) {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = function (event) {
    fabric.loadSVGFromString(event.target.result, (objects, options) => {
      const obj = fabric.util.groupSVGElements(objects, options);
      canvas.add(obj).renderAll();
    });
  };
  reader.readAsText(file);
});





// SHAPE TOOLS...........................................................................

document.querySelectorAll('.tool-dropdown-item').forEach(item => {
  item.addEventListener('click', () => {
    const shapeType = item.dataset.shape;
    addShape(shapeType);
  });
});

function addShape(type) {
let isDrawingShape = false;
let startX, startY;
let tempShape = null;


// When picking a shape from the menu.......................................................

document.querySelectorAll('.tool-dropdown-item').forEach(item => {
  item.addEventListener('click', () => {
    const shapeType = item.dataset.shape;
    currentTool = shapeType;
    shapesList.style.display = 'none';
  });
});


// Mouse down: start drawing shape .........................................................

canvas.on('mouse:down', function(opt) {
  if (!['rectangle','circle','ellipse','line','triangle','polygon'].includes(currentTool)) return;
  
  isDrawingShape = true;
  const pointer = canvas.getPointer(opt.e);
  startX = pointer.x;
  startY = pointer.y;

  const fill = document.getElementById('fill-color').value;
  const stroke = document.getElementById('stroke-color').value;

  if (currentTool === 'rectangle') {
    tempShape = new fabric.Rect({ left: startX, top: startY, width: 0, height: 0, fill, stroke });
  }
  else if (currentTool === 'circle') {
    tempShape = new fabric.Circle({ left: startX, top: startY, radius: 0, fill, stroke });
  }
  else if (currentTool === 'ellipse') {
    tempShape = new fabric.Ellipse({ left: startX, top: startY, rx: 0, ry: 0, fill, stroke });
  }
  else if (currentTool === 'line') {
    tempShape = new fabric.Line([startX, startY, startX, startY], { stroke, strokeWidth: 2 });
  }
  else if (currentTool === 'triangle') {
    tempShape = new fabric.Triangle({ left: startX, top: startY, width: 0, height: 0, fill, stroke });
  }
  else if (currentTool === 'polygon') {
    // Simple 5-point polygon as placeholder
    tempShape = new fabric.Polygon([
      { x: 0, y: -50 },
      { x: 47, y: -15 },
      { x: 29, y: 40 },
      { x: -29, y: 40 },
      { x: -47, y: -15 }
    ], { left: startX, top: startY, scaleX: 0, scaleY: 0, fill, stroke });
  }

  if (tempShape) canvas.add(tempShape);
});



// Mouse move: resize shape dynamically.........................................

canvas.on('mouse:move', function(opt) {
  if (!isDrawingShape || !tempShape) return;
  const pointer = canvas.getPointer(opt.e);

  if (currentTool === 'rectangle' || currentTool === 'triangle') {
    tempShape.set({ width: pointer.x - startX, height: pointer.y - startY });
  }
  else if (currentTool === 'circle') {
    const radius = Math.sqrt(Math.pow(pointer.x - startX, 2) + Math.pow(pointer.y - startY, 2)) / 2;
    tempShape.set({ radius });
  }
  else if (currentTool === 'ellipse') {
    tempShape.set({ rx: Math.abs(pointer.x - startX) / 2, ry: Math.abs(pointer.y - startY) / 2 });
  }
  else if (currentTool === 'line') {
    tempShape.set({ x2: pointer.x, y2: pointer.y });
  }
  else if (currentTool === 'polygon') {
    tempShape.set({ scaleX: (pointer.x - startX) / 100, scaleY: (pointer.y - startY) / 100 });
  }

  canvas.renderAll();
});


// Mouse up: finish shape.........................................................

canvas.on('mouse:up', function() {
  if (isDrawingShape) {
    isDrawingShape = false;
    tempShape = null;
    // Automatically go back to Select tool
    currentTool = 'select';
    document.querySelectorAll('#vector-toolbar .tool').forEach(b => b.classList.remove('active'));
    document.querySelector('#vector-toolbar .tool[data-tool="select"]').classList.add('active');
  }
});


}








// SHAPES DROP DOWN............................

const shapesButton = document.getElementById('shapes-button');
const shapesList = document.getElementById('shapes-list');

shapesButton.addEventListener('click', (e) => {
  e.stopPropagation(); // prevent closing instantly
  shapesList.style.display = shapesList.style.display === 'block' ? 'none' : 'block';
});


// Close dropdown if clicking elsewhere...........................

document.addEventListener('click', () => {
  shapesList.style.display = 'none';
});



// Shape click handler ......................................

document.querySelectorAll('.tool-dropdown-item').forEach(item => {
  item.addEventListener('click', () => {
    const shapeType = item.dataset.shape;
    currentTool = shapeType;
    shapesList.style.display = 'none';
  });
});
