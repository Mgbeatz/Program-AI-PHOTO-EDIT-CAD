// Export as SVG
document.getElementById('export-svg').addEventListener('click', () => {
  const svgData = canvas.toSVG();
  const blob = new Blob([svgData], { type: 'image/svg+xml' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = 'vector_drawing.svg';
  link.click();
});

// Export as PNG
document.getElementById('export-png').addEventListener('click', () => {
  const dataURL = canvas.toDataURL({ format: 'png' });
  const link = document.createElement('a');
  link.href = dataURL;
  link.download = 'vector_drawing.png';
  link.click();
});

// Export as JPEG
document.getElementById('export-jpeg').addEventListener('click', () => {
  const dataURL = canvas.toDataURL({ format: 'jpeg', quality: 0.9 });
  const link = document.createElement('a');
  link.href = dataURL;
  link.download = 'vector_drawing.jpg';
  link.click();
});

// Import SVG
document.getElementById('import-svg').addEventListener('change', function (e) {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = function (event) {
    fabric.loadSVGFromString(event.target.result, (objects, options) => {
      const obj = fabric.util.groupSVGElements(objects, options);
      canvas.add(obj).renderAll();
    });
  };
  reader.readAsText(file);
});





// SHAPE TOOLS...................................

document.querySelectorAll('.tool-dropdown-item').forEach(item => {
  item.addEventListener('click', () => {
    const shapeType = item.dataset.shape;
    addShape(shapeType);
  });
});

function addShape(type) {
  let shape;
  const fill = document.getElementById('fill-color').value;
  const stroke = document.getElementById('stroke-color').value;

  if (type === 'rectangle') {
    shape = new fabric.Rect({
      left: 100, top: 100,
      width: 100, height: 60,
      fill, stroke
    });
  }
  else if (type === 'circle') {
    shape = new fabric.Circle({
      left: 150, top: 150,
      radius: 50,
      fill, stroke
    });
  }
  else if (type === 'ellipse') {
    shape = new fabric.Ellipse({
      left: 150, top: 150,
      rx: 80, ry: 40,
      fill, stroke
    });
  }
  else if (type === 'line') {
    shape = new fabric.Line([50, 100, 200, 100], {
      stroke,
      strokeWidth: 2
    });
  }
  else if (type === 'triangle') {
    shape = new fabric.Triangle({
      left: 150, top: 150,
      width: 100, height: 80,
      fill, stroke
    });
  }
  else if (type === 'polygon') {
    shape = new fabric.Polygon([
      { x: 50, y: 0 },
      { x: 100, y: 50 },
      { x: 75, y: 100 },
      { x: 25, y: 100 },
      { x: 0, y: 50 }
    ], {
      left: 150, top: 150,
      fill, stroke
    });
  }

  if (shape) {
    canvas.add(shape);
    canvas.setActiveObject(shape);
  }
}

const shapesButton = document.getElementById('shapes-button');
const shapesList = document.getElementById('shapes-list');

shapesButton.addEventListener('click', (e) => {
  e.stopPropagation(); // prevent closing instantly
  shapesList.style.display = shapesList.style.display === 'block' ? 'none' : 'block';
});

// Close dropdown if clicking elsewhere...........................

document.addEventListener('click', () => {
  shapesList.style.display = 'none';
});



// Shape click handler ......................................

document.querySelectorAll('.tool-dropdown-item').forEach(item => {
  item.addEventListener('click', () => {
    const shapeType = item.dataset.shape;
    currentTool = shapeType;
    shapesList.style.display = 'none';
  });
});
