const canvas = new fabric.Canvas('vector-canvas', {
  backgroundColor: '#fff',
  width: window.innerWidth - 260,
  height: window.innerHeight
});

let currentTool = 'select';

// Tool selection
document.querySelectorAll('#vector-toolbar .tool').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('#vector-toolbar .tool').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentTool = btn.dataset.tool;
    activateTool(currentTool);
  });
});

// Color changes
document.getElementById('fill-color').addEventListener('input', (e) => {
  const obj = canvas.getActiveObject();
  if (obj) {
    obj.set('fill', e.target.value);
    canvas.renderAll();
  }
});

document.getElementById('stroke-color').addEventListener('input', (e) => {
  const obj = canvas.getActiveObject();
  if (obj) {
    obj.set('stroke', e.target.value);
    canvas.renderAll();
  }
});

// Tool activation
function activateTool(tool) {
  canvas.isDrawingMode = false;
  if (tool === 'pencil') {
    canvas.isDrawingMode = true;
    canvas.freeDrawingBrush = new fabric.PencilBrush(canvas);
    canvas.freeDrawingBrush.color = document.getElementById('stroke-color').value;
    canvas.freeDrawingBrush.width = 2;
  }
  if (tool === 'brush') {
    canvas.isDrawingMode = true;
    canvas.freeDrawingBrush = new fabric.CircleBrush(canvas);
    canvas.freeDrawingBrush.color = document.getElementById('stroke-color').value;
    canvas.freeDrawingBrush.width = 10;
  }
  if (tool === 'shape') {
    canvas.on('mouse:down', function opt(e) {
      const pointer = canvas.getPointer(e.e);
      const rect = new fabric.Rect({
        left: pointer.x,
        top: pointer.y,
        width: 100,
        height: 80,
        fill: document.getElementById('fill-color').value,
        stroke: document.getElementById('stroke-color').value
      });
      canvas.add(rect);
      canvas.off('mouse:down', opt);
    });
  }
  if (tool === 'text') {
    canvas.on('mouse:down', function opt(e) {
      const pointer = canvas.getPointer(e.e);
      const text = new fabric.IText('Text', {
        left: pointer.x,
        top: pointer.y,
        fill: document.getElementById('fill-color').value
      });
      canvas.add(text);
      canvas.off('mouse:down', opt);
    });
  }
}

activateTool('select');
