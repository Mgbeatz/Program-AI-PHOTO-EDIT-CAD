
const canvas = new fabric.Canvas("canvas");
window.vectorCanvas = canvas;

// TOOL EXAMPLES
document.getElementById("pen").addEventListener("click", () => {
  const path = new fabric.Path("M 0 0 L 50 50", {
    left: 100,
    top: 100,
    stroke: "black",
    strokeWidth: 2,
    fill: ""
  });
  canvas.add(path);
});

document.getElementById("live-paint-btn").addEventListener("click", () => {
  canvas.on("mouse:down", function fillShape(e) {
    const target = canvas.findTarget(e.e);
    if (target && target.type === "path" || target.type === "polygon") {
      target.set("fill", "yellow");
      canvas.requestRenderAll();
      canvas.off("mouse:down", fillShape);
    }
  });
});

function traceImageToVector(imageUrl) {
  ImageTracer.imageToSVG(imageUrl, function (svgstr) {
    fabric.loadSVGFromString(svgstr, function (objects, options) {
      const obj = fabric.util.groupSVGElements(objects, options);
      obj.set({ left: 200, top: 200 });
      canvas.add(obj);
    });
  });
}

document.getElementById("image-upload").addEventListener("change", function (e) {
  const file = e.target.files[0];
  const reader = new FileReader();
  reader.onload = function (f) {
    traceImageToVector(f.target.result);
  };
  reader.readAsDataURL(file);
});

document.getElementById("opacity-mask-btn").addEventListener("click", () => {
  const objs = canvas.getActiveObjects();
  if (objs.length === 2) {
    const [base, mask] = objs;
    base.clipPath = mask;
    canvas.discardActiveObject();
    canvas.requestRenderAll();
  } else {
    alert("Select base object and mask object.");
  }
});

document.getElementById("stroke-color").addEventListener("input", e => {
  const obj = canvas.getActiveObject();
  if (obj) {
    obj.set("stroke", e.target.value);
    canvas.requestRenderAll();
  }
});

document.getElementById("stroke-width").addEventListener("input", e => {
  const obj = canvas.getActiveObject();
  if (obj) {
    obj.set("strokeWidth", parseInt(e.target.value));
    canvas.requestRenderAll();
  }
});

document.getElementById("shadow-toggle").addEventListener("change", e => {
  const obj = canvas.getActiveObject();
  if (obj) {
    obj.set("shadow", e.target.checked ? "2px 2px 5px rgba(0,0,0,0.3)" : null);
    canvas.requestRenderAll();
  }
});
